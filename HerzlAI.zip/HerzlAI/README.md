# Aida AI Tutor

An AI-powered educational assistant designed for South African students (Grades 1-12) following the CAPS curriculum, with specialized focus on second-language learning.

## Features

- **CAPS Curriculum Aligned**: Specialized for South African education standards
- **AI-Powered Tutoring**: Uses OpenAI GPT-4o for intelligent conversations
- **Multilingual Support**: Afrikaans learning with English explanations
- **Scaffolded Learning**: Guides students to discover answers rather than providing direct solutions
- **PayFast Integration**: Local South African payment processing
- **WordPress Plugin**: Easy integration with existing websites
- **Multimedia Support**: Image and video analysis capabilities

## Quick Start

### Prerequisites
- Node.js 18+ 
- OpenAI API key
- PayFast merchant account (for payments)

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/aida-ai-tutor.git
cd aida-ai-tutor
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
```bash
cp .env.example .env
# Edit .env with your API keys
```

4. Start the development server:
```bash
npm run dev
```

The application will be available at `http://localhost:5000`

## Environment Variables

```bash
NODE_ENV=development
OPENAI_API_KEY=your_openai_api_key
PAYFAST_MERCHANT_ID=your_payfast_merchant_id
PAYFAST_MERCHANT_KEY=your_payfast_merchant_key
PAYFAST_PASSPHRASE=your_secure_passphrase
BASE_URL=http://localhost:5000
```

## WordPress Integration

The project includes a complete WordPress plugin for easy website integration:

1. Copy the `wordpress-integration` folder contents
2. Upload as a WordPress plugin
3. Configure with your deployment URL
4. Use the `[aida_tutor]` shortcode on any page

See `HELLOAIDA_DEPLOYMENT_GUIDE.md` for detailed instructions.

## Deployment

### Railway (Recommended)
1. Connect your GitHub repository to Railway
2. Set environment variables in Railway dashboard
3. Deploy automatically

### VPS/Server
1. Clone repository on server
2. Install dependencies with `npm install`
3. Set environment variables
4. Start with `pm2 start npm -- start`

## Subscription Plans (ZAR)

- **Basic Plan**: R99/month - 5 hours tutoring, email support
- **Premium Plan**: R199/month - Unlimited tutoring, advanced features
- **Annual Plan**: R1999/year - Premium features + family sharing

## Tech Stack

- **Frontend**: React + TypeScript + Tailwind CSS
- **Backend**: Node.js + Express
- **Database**: PostgreSQL with Drizzle ORM
- **AI**: OpenAI GPT-4o
- **Payments**: PayFast (South African)
- **Build**: Vite
- **Deployment**: Railway/Vercel/VPS

## Contributing

This project is designed for South African educational needs. Contributions should align with CAPS curriculum requirements and local market preferences.

## License

MIT License - see LICENSE file for details.

## Support

For technical support or deployment questions, see the comprehensive deployment guide in `HELLOAIDA_DEPLOYMENT_GUIDE.md`.